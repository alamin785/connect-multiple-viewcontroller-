//
//  secondViewController.swift
//  demoauto
//
//  Created by alamin on 3/1/19.
//  Copyright © 2019 alamin. All rights reserved.
//

import UIKit

class secondViewController: UIViewController {

    @IBOutlet weak var mylabel: UILabel!
    
    var str : String?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        mylabel.text = str
    }
    

   
    @IBAction func next(_ sender: Any) {
        
        performSegue(withIdentifier: "second", sender: self)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
      segue.destination as? ThirdViewController
        
    }
    
}
