//
//  fourthViewController.swift
//  demoauto
//
//  Created by alamin on 3/2/19.
//  Copyright © 2019 alamin. All rights reserved.
//

import UIKit

class fourthViewController: UIViewController {

    @IBOutlet weak var bbclick: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
         self.roundbtn(btn:bbclick)

        // Do any additional setup after loading the view.
    }
    
    func roundbtn(btn:AnyObject) {
        if #available(iOS 12.0, *) {
            btn.layer.cornerRadius = btn.frame.size.height/2
        } else {
            // Fallback on earlier versions
        }
        btn.layer.masksToBounds = true
    }
    
    @IBAction func next(_ sender: Any) {
        
        performSegue(withIdentifier: "fourth", sender: self)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        segue.destination as? FiveViewController
    }
    
}
