//
//  ViewController.swift
//  demoauto
//
//  Created by alamin on 2/28/19.
//  Copyright © 2019 alamin. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var btnclick: UIButton!
    @IBOutlet weak var textfieldoutlet: UITextField!
    
    @IBAction func storybook(_ sender: Any) {
        if textfieldoutlet.text == ""{
            
            print("empty")
        }else{
            performSegue(withIdentifier: "seco", sender: self)
        }
        func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            let ob = segue.destination as? secondViewController
            ob?.str = textfieldoutlet.text
        
    }
    }
    @IBAction func historybook(_ sender: Any) {
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.roundbtn(btn: btnclick)
        
    }


    @IBAction func add(_ sender: Any) {
        
        
       performSegue(withIdentifier: "seco", sender: self)
}
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let ob = segue.destination as? secondViewController
        ob?.str = textfieldoutlet.text!
    }
    func roundbtn(btn:AnyObject) {
        if #available(iOS 12.0, *) {
            btn.layer.cornerRadius = btn.frame.size.height/2
        } else {
            // Fallback on earlier versions
        }
        btn.layer.masksToBounds = true
    }
}
