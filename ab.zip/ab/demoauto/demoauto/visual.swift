//
//  visual.swift
//  demoauto
//
//  Created by alamin on 3/2/19.
//  Copyright © 2019 alamin. All rights reserved.
//

import UIKit

class visual: UIVisualEffectView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
