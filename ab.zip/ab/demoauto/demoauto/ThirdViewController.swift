//
//  ThirdViewController.swift
//  demoauto
//
//  Created by alamin on 3/2/19.
//  Copyright © 2019 alamin. All rights reserved.
//

import UIKit

class ThirdViewController: UIViewController {
    
    var text1 = UITextField()
    @IBOutlet weak var button: UIButton!
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        let fram = CGRect(x: 50, y: 100, width: 250, height: 70)
        text1 = UITextField(frame: fram)
        text1.backgroundColor = UIColor.gray
        self.view.addSubview(text1)
        
        let button = UIButton.init(type:.custom)
        button.frame = CGRect(x: 100, y: 180, width: 150, height: 80)
        button.backgroundColor = UIColor.white
        button.setTitle("Clicked", for: .normal)
        self.view.addSubview(button)
        

        
    }
    

   
    @IBAction func nextclick(_ sender: Any) {
        performSegue(withIdentifier: "third", sender: self)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        segue.destination as? fourthViewController
    }
   /*
    func roundbtn1(bt:AnyObject) {
        if #available(iOS 12.0, *) {
            bt.layer.cornerRadius = bt.frame.size.height/2
        } else {
            
        }
        bt.layer.masksToBounds = true
    }
 */
    
}
