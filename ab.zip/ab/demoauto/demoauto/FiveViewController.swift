//
//  FiveViewController.swift
//  demoauto
//
//  Created by alamin on 3/3/19.
//  Copyright © 2019 alamin. All rights reserved.
//

import UIKit

class FiveViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        alert()    }
    
    @IBAction func alert(_ sender: Any) {
        alert()
        
       
    }
    func alert(){
        let alert1 = UIAlertController(title: "input text", message: "yor message missing", preferredStyle: .alert)
        let diss = UIAlertAction(title: "cancel", style: .cancel, handler: {
            (alert1:UIAlertAction!) -> Void in
        })
        
      alert1.addAction(diss)
        self.present(alert1,animated: true,completion: nil)
        
    }
    

}
